import numpy as np
import dsp_core as dsp

def test_sin_idft_roundtrip():
    x = dsp.gen_sin(50, fs=1000, n=128)
    X = dsp.dft(x)
    xr = dsp.idft(X)
    assert np.allclose(x, xr, atol=1e-12)


def test_large_dft_idft():
    N = 4096
    x = dsp.gen_cos(100, fs=8000, n=N)
    X = dsp.dft(x)
    xr = dsp.idft(X)
    assert np.allclose(x, xr, atol=1e-10)


def test_convolve1d_length_and_values():
    x = [1.0, 2.0, 3.0]
    k = [0.5, 0.5]
    y = dsp.convolve1d(x, k)
    assert y.shape == (4,)
    assert np.allclose(y, [0.5, 1.5, 2.5, 1.5], atol=1e-12)


def test_gauss1d_kernel_sum():
    k = dsp.gauss1d(sigma=1.0, radius=3)
    assert np.isclose(np.sum(k), 1.0, atol=1e-12)


def test_convolve2d_identity():
    img = np.random.rand(8, 8)
    delta = np.zeros((3, 3)); delta[1,1] = 1.0
    out = dsp.convolve2d(img, delta)
    assert out.shape == img.shape
    assert np.allclose(out, img, atol=1e-12)


def test_gaussian_blur_and_sobel_shapes():
    img = np.eye(10)
    blurred = dsp.gaussian_blur(img, sigma=1.5, radius=2)
    edges = dsp.edge_sobel(img)
    assert blurred.shape == img.shape
    assert edges.shape == img.shape
    assert np.all(blurred >= 0)
    assert np.all(edges >= 0)


def test_threshold_and_noise():
    x = np.zeros(100)
    noisy = dsp.add_noise(x, stddev=0.1, seed=42)
    thr = dsp.threshold(noisy, thr=0.0)
    assert set(np.unique(thr)).issubset({0.0, 1.0})


def test_correlation_and_autocorrelation():
    a = np.array([1.0, 2.0, 3.0])
    b = np.array([0.0, 1.0])
    corr = dsp.correlation(a, b)
    expected = np.convolve(a, b)
    assert np.allclose(corr, expected, atol=1e-12)
    auto = dsp.autocorrelation(a)
    expected_auto = np.convolve(a, a)
    assert np.allclose(auto, expected_auto, atol=1e-12)


def test_find_peaks():
    x = np.array([0.0, 1.0, 0.0, 2.0, 0.0, 1.0, 0.0])
    idx = dsp.find_peaks(x, threshold=0.5)
    assert np.array_equal(idx, np.array([1, 3, 5]))


def test_rect_and_saw_generators():
    n = 100
    rect = dsp.gen_rect(5, fs=50, n=n, duty=0.3)
    assert rect.shape == (n,)
    ones = np.sum(rect > 0)
    assert ones == int(np.floor(n * 0.3)) or ones == int(np.ceil(n * 0.3))
    saw = dsp.gen_saw(5, fs=50, n=n)
    assert saw.shape == (n,)
    diffs = np.diff(saw)
    assert np.any(diffs < 0)


def test_derivative():
    x = np.array([0.0, 1.0, 3.0, 6.0])
    d = dsp.derivative(x)
    assert np.allclose(d, [1.0, 2.0, 3.0], atol=1e-12)


def test_freq_filters_identity_and_zero():
    x = dsp.gen_sin(5, fs=100, n=128)
    # remove_high_freq:
    #   cutoff_ratio=0.0 → zeros; cutoff_ratio=1.0 → identity
    hl_zero = dsp.remove_high_freq(x, cutoff_ratio=0.0)
    hl_id   = dsp.remove_high_freq(x, cutoff_ratio=1.0)
    # remove_low_freq:
    #   cutoff_ratio=0.0 → identity; cutoff_ratio=1.0 → zeros
    ll_id   = dsp.remove_low_freq(x, cutoff_ratio=0.0)
    ll_zero = dsp.remove_low_freq(x, cutoff_ratio=1.0)

    assert hl_zero.shape == x.shape
    assert hl_id.shape   == x.shape
    assert ll_id.shape   == x.shape
    assert ll_zero.shape == x.shape

    assert np.allclose(hl_zero, np.zeros_like(x), atol=1e-6)
    assert np.allclose(hl_id,   x,             atol=1e-6)
    assert np.allclose(ll_id,   x,             atol=1e-6)
    assert np.allclose(ll_zero, np.zeros_like(x), atol=1e-6)



def test_bilinear_resize():
    img = np.array([[1.0, 2.0], [3.0, 4.0]])
    out = dsp.bilinear_resize(img, newH=4, newW=4)
    assert out.shape == (4, 4)
    assert np.isclose(out[0, 0], 1.0)
    assert np.isclose(out[-1, -1], 4.0)
