#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <algorithm>
#include <cstdint>
#include "dsp_core.hpp"
#include <matplot/matplot.h>

namespace py = pybind11;
using namespace dsp;

// ------------------- helpers -------------------
template<typename T>
py::array_t<T> vec_to_np(const std::vector<T>& v) {
    return py::array_t<T>(v.size(), v.data());
}

template<typename T>
std::vector<T> np_to_vec(const py::array_t<T>& a) {
    const T* ptr = a.data();
    return std::vector<T>(ptr, ptr + a.size());
}

py::array_t<double> mat_to_np(const matd& m) {
    if (m.empty()) return py::array_t<double>();
    std::size_t H = m.size(), W = m[0].size();
    py::array_t<double> arr({H, W});
    double* dst = arr.mutable_data();
    for (std::size_t y = 0; y < H; ++y)
        std::copy(m[y].begin(), m[y].end(), dst + y * W);
    return arr;
}

matd np_to_mat(const py::array_t<double>& a) {
    if (a.ndim() != 2) throw std::runtime_error("expecting 2-D array");
    std::size_t H = a.shape(0), W = a.shape(1);
    const double* src = a.data();
    matd m(H, vecd(W));
    for (std::size_t y = 0; y < H; ++y)
        std::copy(src + y * W, src + (y + 1) * W, m[y].begin());
    return m;
}

// ------------------- module -------------------
PYBIND11_MODULE(dsp_core, m) {
    m.doc() = "Rozszerzony rdzeń DSP (C++ / pybind11)";

    // --- generators ---
    m.def("gen_sin", [](double f, double fs, std::size_t n, double phase) {
        return vec_to_np(gen_sin(f, fs, n, phase));
    }, py::arg("f"), py::arg("fs"), py::arg("n"), py::arg("phase") = 0.0);

    m.def("gen_cos", [](double f, double fs, std::size_t n, double phase) {
        return vec_to_np(gen_cos(f, fs, n, phase));
    }, py::arg("f"), py::arg("fs"), py::arg("n"), py::arg("phase") = 0.0);

    m.def("gen_rect", [](double f, double fs, std::size_t n, double duty) {
        return vec_to_np(gen_rect(f, fs, n, duty));
    }, py::arg("f"), py::arg("fs"), py::arg("n"), py::arg("duty") = 0.5);

    m.def("gen_saw", [](double f, double fs, std::size_t n) {
        return vec_to_np(gen_saw(f, fs, n));
    }, py::arg("f"), py::arg("fs"), py::arg("n"));

    // --- utility kernels ---
    m.def("gauss1d", [](double sigma, int radius) {
        return vec_to_np(gauss1d(sigma, radius));
    }, py::arg("sigma"), py::arg("radius"));

    // --- DFT ---
    m.def("dft", [](py::array_t<double> x) {
        return vec_to_np(dft(np_to_vec<double>(x)));
    }, py::arg("x"));

    m.def("idft", [](py::array_t<std::complex<double>> X) {
        return vec_to_np(idft(np_to_vec<std::complex<double>>(X)));
    }, py::arg("X"));

    // --- convolution ---
    m.def("convolve1d", [](py::array_t<double> s, py::array_t<double> kernel) {
        return vec_to_np(convolve1d(np_to_vec<double>(s), np_to_vec<double>(kernel)));
    }, py::arg("s"), py::arg("kernel"));

    m.def("convolve2d", [](py::array_t<double> img, py::array_t<double> kernel) {
        return mat_to_np(convolve2d(np_to_mat(img), np_to_mat(kernel)));
    }, py::arg("img"), py::arg("kernel"));

    // --- basic ops ---
    m.def("derivative", [](py::array_t<double> x) {
        return vec_to_np(derivative(np_to_vec<double>(x)));
    }, py::arg("x"));

    m.def("add_noise", [](py::array_t<double> x, double stddev, std::uint32_t seed) {
        return vec_to_np(add_noise(np_to_vec<double>(x), stddev, seed));
    }, py::arg("x"), py::arg("stddev"), py::arg("seed") = 0);

    m.def("threshold", [](py::array_t<double> x, double thr) {
        return vec_to_np(threshold(np_to_vec<double>(x), thr));
    }, py::arg("x"), py::arg("thr"));

    // --- correlation ---
    m.def("correlation", [](py::array_t<double> a, py::array_t<double> b) {
        return vec_to_np(correlation(np_to_vec<double>(a), np_to_vec<double>(b)));
    }, py::arg("a"), py::arg("b"));

    m.def("autocorrelation", [](py::array_t<double> x) {
        return vec_to_np(autocorrelation(np_to_vec<double>(x)));
    }, py::arg("x"));

    // --- freq filtering ---
    m.def("remove_high_freq", [](py::array_t<double> x, double cutoff_ratio) {
        return vec_to_np(remove_high_freq(np_to_vec<double>(x), cutoff_ratio));
    }, py::arg("x"), py::arg("cutoff_ratio"));

    m.def("remove_low_freq", [](py::array_t<double> x, double cutoff_ratio) {
        return vec_to_np(remove_low_freq(np_to_vec<double>(x), cutoff_ratio));
    }, py::arg("x"), py::arg("cutoff_ratio"));

    // --- image ops ---
    m.def("gaussian_blur", [](py::array_t<double> img, double sigma, int radius) {
        return mat_to_np(gaussian_blur(np_to_mat(img), sigma, radius));
    }, py::arg("img"), py::arg("sigma"), py::arg("radius"));

    m.def("edge_sobel", [](py::array_t<double> img) {
        return mat_to_np(edge_sobel(np_to_mat(img)));
    }, py::arg("img"));

    m.def("bilinear_resize", [](py::array_t<double> img, std::size_t newH, std::size_t newW) {
        return mat_to_np(bilinear_resize(np_to_mat(img), newH, newW));
    }, py::arg("img"), py::arg("newH"), py::arg("newW"));
    
    m.def("show_signal", [](py::array_t<double> x){
    auto v = np_to_vec<double>(x);
    matplot::plot(v);
    matplot::show();
    }, py::arg("x"),
    "Wyświetla sygnał x za pomocą matplotplusplus");
    
    m.def("find_peaks",
    [](py::array_t<double> a, double thr) {
        auto v  = np_to_vec<double>(a);
        auto pi = find_peaks(v, thr);
        return py::array_t<std::size_t>(pi.size(), pi.data());
    },
    py::arg("x"), py::arg("threshold") = 0.0,
    "Zwraca ndarray indeksów lokalnych maksimów większych niż threshold");

}

