// dsp_core.hpp — rozszerzona wersja (DSP core)
// --------------------------------------------------
#ifndef DSP_CORE_HPP
#define DSP_CORE_HPP

#include <vector>
#include <complex>
#include <cmath>
#include <stdexcept>
#include <random>
#include <algorithm>

namespace dsp {

// typy pomocnicze
using cdouble = std::complex<double>;
using vecd    = std::vector<double>;
using veccd   = std::vector<cdouble>;
using matd    = std::vector<std::vector<double>>; // prosta macierz 2D

constexpr double PI = 3.141592653589793238462643383279502884;

// --------------------------------------------------
// Generatory sygnałów podstawowych
// --------------------------------------------------
inline vecd gen_sin(double f, double fs, std::size_t N, double phase = 0.0)
{
    if (fs <= 0.0) throw std::invalid_argument("fs > 0");
    vecd y(N);
    const double w = 2.0 * PI * f / fs;
    for (std::size_t n = 0; n < N; ++n) y[n] = std::sin(w * n + phase);
    return y;
}

inline vecd gen_cos(double f, double fs, std::size_t N, double phase = 0.0)
{
    if (fs <= 0.0) throw std::invalid_argument("fs > 0");
    vecd y(N);
    const double w = 2.0 * PI * f / fs;
    for (std::size_t n = 0; n < N; ++n) y[n] = std::cos(w * n + phase);
    return y;
}

inline vecd gen_rect(double f, double fs, std::size_t N, double duty = 0.5)
{
    if (fs <= 0.0 || duty<=0.0 || duty>=1.0) throw std::invalid_argument("parametry niepoprawne");
    vecd y(N);
    const double T = fs / f; // okres w próbkach
    for (std::size_t n = 0; n < N; ++n) y[n] = (std::fmod(n, T) < duty*T) ? 1.0 : -1.0;
    return y;
}

inline vecd gen_saw(double f, double fs, std::size_t N)
{
    if (fs <= 0.0) throw std::invalid_argument("fs > 0");
    vecd y(N);
    const double T = fs / f;
    for (std::size_t n = 0; n < N; ++n) y[n] = 2.0*(std::fmod(n, T)/T) - 1.0; // zakres -1..1
    return y;
}

// --------------------------------------------------
// DFT / IDFT (jak wcześniej)
// --------------------------------------------------
inline veccd dft(const vecd& x)
{
    const std::size_t N = x.size();
    veccd X(N);
    for (std::size_t k = 0; k < N; ++k) {
        cdouble sum{0.0, 0.0};
        for (std::size_t n = 0; n < N; ++n) {
            double angle = -2.0 * PI * k * n / N;
            sum += x[n] * std::exp(cdouble{0.0, angle});
        }
        X[k] = sum;
    }
    return X;
}

inline vecd idft(const veccd& X)
{
    const std::size_t N = X.size();
    vecd x(N);
    for (std::size_t n = 0; n < N; ++n) {
        cdouble sum{0.0, 0.0};
        for (std::size_t k = 0; k < N; ++k) {
            double angle = 2.0 * PI * k * n / N;
            sum += X[k] * std::exp(cdouble{0.0, angle});
        }
        x[n] = sum.real() / static_cast<double>(N);
    }
    return x;
}

// --------------------------------------------------
// Konwolucja 1D i 2D
// --------------------------------------------------
inline vecd convolve1d(const vecd& signal, const vecd& kernel)
{
    if (signal.empty() || kernel.empty()) throw std::invalid_argument("puste");
    std::size_t N = signal.size(), M = kernel.size();
    vecd out(N+M-1, 0.0);
    for (std::size_t n=0;n<N;++n)
        for (std::size_t m=0;m<M;++m)
            out[n+m] += signal[n]*kernel[M-1-m];
    return out;
}

inline matd convolve2d(const matd& img, const matd& kernel)
{
    std::size_t H = img.size(); if (!H) return {};
    std::size_t W = img[0].size();
    std::size_t KH = kernel.size();
    std::size_t KW = kernel[0].size();
    std::size_t padH = KH/2, padW = KW/2;
    matd out(H, vecd(W, 0.0));
    for (std::size_t y=0;y<H;++y)
        for (std::size_t x=0;x<W;++x)
            for (std::size_t ky=0;ky<KH;++ky)
                for (std::size_t kx=0;kx<KW;++kx) {
                    int iy = int(y)+int(ky)-int(padH);
                    int ix = int(x)+int(kx)-int(padW);
                    if (iy>=0 && iy<(int)H && ix>=0 && ix<(int)W)
                        out[y][x] += img[iy][ix]*kernel[KH-1-ky][KW-1-kx];
                }
    return out;
}

// --------------------------------------------------
// Prosty operator pochodnej (różnica w przód)
// --------------------------------------------------
inline vecd derivative(const vecd& x)
{
    if (x.size()<2) return {};
    vecd d(x.size()-1);
    for (std::size_t i=0;i<d.size();++i) d[i]=x[i+1]-x[i];
    return d;
}

// --------------------------------------------------
// Dodawanie białego szumu (Gauss, stddev)
// --------------------------------------------------
inline vecd add_noise(const vecd& x, double stddev, std::uint32_t seed=0)
{
    std::mt19937 gen(seed); std::normal_distribution<double> dist(0.0,stddev);
    vecd y=x; for(auto& v:y) v+=dist(gen); return y;
}

// --------------------------------------------------
// Threshold (progowanie binarne)
// --------------------------------------------------
inline vecd threshold(const vecd& x, double thr)
{
    vecd y(x.size());
    for (std::size_t i=0;i<x.size();++i) y[i]=(x[i]>thr)?1.0:0.0;
    return y;
}

// --------------------------------------------------
// Korelacja oraz autokorelacja (pełna, bez normalizacji)
// --------------------------------------------------
inline vecd correlation(const vecd& a, const vecd& b)
{
    if (a.empty()||b.empty()) throw std::invalid_argument("puste");
    vecd r(a.size()+b.size()-1,0.0);
    for(std::size_t i=0;i<a.size();++i)
        for(std::size_t j=0;j<b.size();++j)
            r[i+j]+=a[i]*b[j];
    return r;
}

inline vecd autocorrelation(const vecd& x)
{
    return correlation(x,x);
}

// --------------------------------------------------
// Usuwanie pasm częstotliwości (DFT)
// --------------------------------------------------
inline vecd remove_high_freq(const vecd& x, double cutoff_ratio)
{
    auto X=dft(x); std::size_t N=X.size();
    std::size_t kcut=static_cast<std::size_t>(cutoff_ratio*N);
    for(std::size_t k=kcut;k<N-kcut;++k) X[k]=0.0;
    return idft(X);
}
inline vecd remove_low_freq(const vecd& x, double cutoff_ratio)
{
    auto X=dft(x); std::size_t N=X.size();
    std::size_t kcut=static_cast<std::size_t>(cutoff_ratio*N);
    for(std::size_t k=0;k<kcut;++k) {X[k]=0.0; X[N-k-1]=0.0;}
    return idft(X);
}

// --------------------------------------------------
// Pomocniczy kernel Gaussa 1D i 2D
// --------------------------------------------------
inline vecd gauss1d(double sigma,int radius)
{
    int size=2*radius+1; vecd k(size);
    double s2=2*sigma*sigma; double sum=0;
    for(int i=-radius;i<=radius;++i){double v=std::exp(-(i*i)/s2);k[i+radius]=v;sum+=v;}
    for(double& v:k) v/=sum; return k;
}
inline matd gauss2d(double sigma,int radius)
{
    vecd g1=gauss1d(sigma,radius);
    int size=g1.size(); matd k(size,vecd(size));
    for(int y=0;y<size;++y)
        for(int x=0;x<size;++x) k[y][x]=g1[y]*g1[x];
    return k;
}

// --------------------------------------------------
// Gauss blur 2D
// --------------------------------------------------
inline matd gaussian_blur(const matd& img,double sigma,int radius)
{
    return convolve2d(img, gauss2d(sigma,radius));
}

// --------------------------------------------------
// Sobel edge detection (magnitude)
// --------------------------------------------------
inline matd edge_sobel(const matd& img)
{
    static const matd Kx{{-1,0,1},{-2,0,2},{-1,0,1}};
    static const matd Ky{{-1,-2,-1},{0,0,0},{1,2,1}};
    matd gx=convolve2d(img,Kx);
    matd gy=convolve2d(img,Ky);
    std::size_t H=img.size(), W=img[0].size();
    matd mag(H,vecd(W,0.0));
    for(std::size_t y=0;y<H;++y) for(std::size_t x=0;x<W;++x)
        mag[y][x]=std::hypot(gx[y][x],gy[y][x]);
    return mag;
}

// --------------------------------------------------
// Bilinear interpolation na siatce (skalowanie)
// --------------------------------------------------
inline matd bilinear_resize(const matd& src,std::size_t newH,std::size_t newW)
{
    std::size_t H=src.size(), W=src[0].size();
    matd out(newH, vecd(newW,0.0));
    double yRatio=double(H-1)/double(newH-1);
    double xRatio=double(W-1)/double(newW-1);
    for(std::size_t y=0;y<newH;++y){
        double sy=y*yRatio; std::size_t y0=floor(sy); std::size_t y1=std::min(y0+1,H-1); double dy=sy-y0;
        for(std::size_t x=0;x<newW;++x){
            double sx=x*xRatio; std::size_t x0=floor(sx); std::size_t x1=std::min(x0+1,W-1); double dx=sx-x0;
            double v00=src[y0][x0], v10=src[y0][x1], v01=src[y1][x0], v11=src[y1][x1];
            out[y][x]= (1-dy)*((1-dx)*v00+dx*v10)+ dy*((1-dx)*v01+dx*v11);
        }
    }
    return out;
}
// --------------------------------------------------
// Wykrywanie pików (lokalne maksima powyżej progu)
// --------------------------------------------------
inline std::vector<std::size_t> find_peaks(const vecd& x, double thr = 0.0) {
    std::vector<std::size_t> peaks;
    if (x.size() < 3) return peaks;
    for (std::size_t i = 1; i + 1 < x.size(); ++i) {
        if (x[i] > x[i-1] && x[i] > x[i+1] && x[i] > thr)
            peaks.push_back(i);
    }
    return peaks;
}


} // namespace dsp

#endif // DSP_CORE_HPP
